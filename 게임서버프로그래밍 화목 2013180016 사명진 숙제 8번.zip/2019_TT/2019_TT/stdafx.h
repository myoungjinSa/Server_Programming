#pragma once
#include <Windows.h>
#include <stdio.h>
#include <iostream>
#include <memory>



#pragma comment(lib,"ws2_32.lib")


